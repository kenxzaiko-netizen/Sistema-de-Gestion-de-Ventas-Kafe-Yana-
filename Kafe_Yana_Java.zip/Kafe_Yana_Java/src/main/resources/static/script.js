
(() => {

    const root = document.querySelector('#novedadesCarousel');
    const slides = [...root.querySelectorAll('.carousel-item')];
    const count = document.querySelector('#count');
    const pause = document.querySelector('#pause');

    let active = 0;
    let running = !matchMedia('(prefers-reduced-motion: reduce)').matches;
    let timer = null;

    const boot = window.bootstrap?.Carousel
        ? new bootstrap.Carousel(root, {
            interval: false,
            touch: true,
            ride: false
        })
        : null;

    // Mostrar diapositivas
    function show(i) {

        active = (i + slides.length) % slides.length;

        if (boot) {
            boot.to(active);
        } else {
            slides.forEach((s, n) =>
                s.classList.toggle('active', n === active)
            );
        }

        count.textContent =
            String(active + 1).padStart(2, '0') + ' / 03';
    }

    // Ejecutar o detener el carrusel automático
    function run() {

        clearInterval(timer);

        if (running) {
            timer = setInterval(() => show(active + 1), 6000);
        }

        pause.textContent = running ? 'Pausar' : 'Reproducir';

        pause.setAttribute(
            'aria-label',
            running ? 'Pausar anuncios' : 'Reproducir anuncios'
        );
    }

    // Botón siguiente
    document.querySelector('#next').addEventListener('click', () => {
        show(active + 1);
        run();
    });

    // Botón anterior
    document.querySelector('#previous').addEventListener('click', () => {
        show(active - 1);
        run();
    });

    // Botón pausar y reproducir
    pause.addEventListener('click', () => {
        running = !running;
        run();
    });

    // Actualizar contador al cambiar de diapositiva
    root.addEventListener('slid.bs.carousel', e => {

        active = e.to;

        count.textContent =
            String(active + 1).padStart(2, '0') + ' / 03';

    });

    // Control táctil para dispositivos móviles
    let start = 0;

    root.addEventListener('touchstart', e => {
        start = e.touches[0].clientX;
    }, { passive: true });

    root.addEventListener('touchend', e => {

        if (!boot) {

            let diff = e.changedTouches[0].clientX - start;

            if (Math.abs(diff) > 45) {
                show(active + (diff < 0 ? 1 : -1));
                run();
            }

        }

    }, { passive: true });

    // Menú de navegación para dispositivos móviles
    const toggle = document.querySelector('.menu-toggle');
    const links = document.querySelector('.navlinks');

    toggle.addEventListener('click', () => {

        let open = links.classList.toggle('open');

        toggle.setAttribute('aria-expanded', String(open));

    });

    // Cerrar menú al seleccionar un enlace
    links.addEventListener('click', e => {

        if (e.target.closest('a')) {

            links.classList.remove('open');

            toggle.setAttribute('aria-expanded', 'false');

        }

    });

    // Iniciar carrusel
    run();

})();
