package bo.kafeyana;

import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import java.util.*;

@RestController
@RequestMapping("/api")
public class CompraController {
    private final JdbcTemplate db;
    public CompraController(JdbcTemplate db) { this.db = db; }

    public record Item(Integer producto_id, Integer cantidad) {}
    public record Solicitud(String cliente, List<Item> articulos) {}

    @GetMapping("/productos")
    public List<Map<String, Object>> productos() {
        return db.queryForList("SELECT id,nombre,precio_centavos FROM productos ORDER BY id");
    }

    @GetMapping("/compras")
    public List<Map<String, Object>> compras() {
        List<Map<String, Object>> compras = db.queryForList("SELECT id,cliente,fecha,total_centavos FROM compras ORDER BY id DESC LIMIT 100");
        for (Map<String, Object> compra : compras) {
            compra.put("detalles", db.queryForList("SELECT producto_nombre,cantidad,precio_unitario_centavos,subtotal_centavos FROM detalle_compra WHERE compra_id=? ORDER BY id", compra.get("id")));
        }
        return compras;
    }

    @PostMapping("/compras")
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public Map<String, Object> registrar(@RequestBody Solicitud solicitud) {
        if (solicitud == null || solicitud.cliente() == null || solicitud.cliente().isBlank() || solicitud.cliente().trim().length() > 100)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ingresa un nombre de hasta 100 caracteres.");
        if (solicitud.articulos() == null || solicitud.articulos().isEmpty() || solicitud.articulos().size() > 20)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Agrega productos al carrito.");
        Map<Integer, Integer> cantidades = new LinkedHashMap<>();
        for (Item item : solicitud.articulos()) {
            if (item == null || item.producto_id() == null || item.cantidad() == null || item.cantidad() < 1 || item.cantidad() > 99)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "La cantidad debe estar entre 1 y 99.");
            cantidades.merge(item.producto_id(), item.cantidad(), Integer::sum);
            if (cantidades.get(item.producto_id()) > 99)
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Máximo 99 unidades por producto.");
        }
        List<Object[]> detalles = new ArrayList<>();
        int total = 0;
        for (Map.Entry<Integer, Integer> entry : cantidades.entrySet()) {
            List<Map<String, Object>> productos = db.queryForList("SELECT id,nombre,precio_centavos FROM productos WHERE id=?", entry.getKey());
            if (productos.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Producto no encontrado.");
            Map<String, Object> producto = productos.get(0);
            int precio = ((Number) producto.get("precio_centavos")).intValue();
            int subtotal = precio * entry.getValue();
            total += subtotal;
            detalles.add(new Object[]{entry.getKey(), producto.get("nombre"), entry.getValue(), precio, subtotal});
        }
        Integer id = db.queryForObject("INSERT INTO compras (cliente,total_centavos) VALUES (?,?) RETURNING id", Integer.class, solicitud.cliente().trim(), total);
        for (Object[] detalle : detalles) {
            db.update("INSERT INTO detalle_compra (compra_id,producto_id,producto_nombre,cantidad,precio_unitario_centavos,subtotal_centavos) VALUES (?,?,?,?,?,?)", id, detalle[0], detalle[1], detalle[2], detalle[3], detalle[4]);
        }
        return Map.of("id", id, "total_centavos", total, "mensaje", "Compra registrada correctamente.");
    }
}
